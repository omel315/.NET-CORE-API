﻿namespace Project_Demo
{
    public interface IExceptionHandlerFilter
    {
    }
}