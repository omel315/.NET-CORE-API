using Microsoft.EntityFrameworkCore;
using Raven.Client.Exceptions.Routing;
using System.Data.Entity.ModelConfiguration;
using System.Data.SqlClient;
using System.Data.Entity;
using Microsoft.AspNetCore.Diagnostics;
using System.Net;
using Project_Demo.Configuration;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddServices();

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();
//// Enable exception handling middleware
//app.UseExceptionHandler("/Error");

//// Add other middleware components here

//// Use the default routing middleware
//app.UseRouting();
app.MapControllers();

app.UseExceptionHandler(
    options =>
    {
        options.Run(async context =>
        {
            context.Response.StatusCode = (int)HttpStatusCode.BadRequest;
            context.Response.ContentType = "text/html";
            var exceptionObject = context.Features.Get<IExceptionHandlerFeature>();
            if (null != exceptionObject)
            {
                var errorMessage = $"{exceptionObject.Error.Message}";
                await context.Response.WriteAsync(errorMessage).ConfigureAwait(false);
            }
        });
    }
);

app.Run();
