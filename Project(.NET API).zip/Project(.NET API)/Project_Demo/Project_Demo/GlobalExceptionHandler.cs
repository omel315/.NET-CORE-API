﻿using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Raven.Client.Exceptions.Routing;

namespace Project_Demo
{
    public class GlobalExceptionHandler : IExceptionHandlerFilter
    {
        public void OnException(ExceptionContext context)
        {
            if (context.Exception is RouteNotFoundException)
            {
                context.HttpContext.Response.StatusCode = 404;
                context.Result = new JsonResult(new { message = "Invalid route" });
            }
            else if (context.Exception is DbUpdateException)
            {
                context.HttpContext.Response.StatusCode = 500;
                context.Result = new JsonResult(new { message = "Database error" });
            }
            else
            {
                context.HttpContext.Response.StatusCode = 500;
                context.Result = new JsonResult(new { message = "Unexpected error" });
            }
        }
    }
}
