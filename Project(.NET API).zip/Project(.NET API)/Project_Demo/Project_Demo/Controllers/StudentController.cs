﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Microsoft.VisualStudio.Services.DelegatedAuthorization;
using Project_Demo.DataModels;
using Project_Demo.Interfaces;
using Project_Demo.Models;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace Project_Demo.Controllers
{
    
    [Route("api/Students")]
    [Consumes("application/json")]
    [Produces("application/json")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly IStudentService _studentService;
        public StudentController(IStudentService studentService) 
        {
            _studentService = studentService;
        }
        // Task 1: Building a Simple API
        [HttpGet]
         public List<StudentModel> GetStudents()
         {
            return _studentService.LoadStudents();
         }
        // Task 2 & 3:  Database Integration with Entity Framework
        [HttpGet]
        [Route("GetStudentsFromDB")]
        public List<TblStudent> GetStudentsFromDB(string Username,string Password)
        {
            
            if (_studentService.Authenticated(Username, Password)) { return LoadStudentsFromDB();  }
            else { throw new UnauthorizedAccessException("Unauthorized access to student data."); }    

        }
        [HttpPost]
        public string AddStudent(TblStudent student)
        {
            StudentManagementSystemContext context = new StudentManagementSystemContext();
            context.Add(student);
            context.SaveChanges();
            return "Student Added Successfully";
        }
        //Task 4: Asynchronous Programming
        [HttpPost]
        [Route("AddStudenWithAsyncProgramming")]
        public async Task<string> AddStudentAsync(TblStudent student)
        {
            using (var context = new StudentManagementSystemContext())
            {
                await context.AddAsync(student);
                await context.SaveChangesAsync();
                return "Student Added Successfully";
            }
        }
        [HttpGet]
        [Route("GetStudentsFromDBWithAsync")]
        public async Task<IEnumerable<TblStudent>> GetStudentsFromDBWithAsync(string Username, string Password)
        {
            if (_studentService.Authenticated(Username, Password))
            {
                // Ensure consistent data format with LoadStudentsFromDB
                IEnumerable<TblStudent> students = await _studentService.LoadStudentsFromDB();
                return students;
            }
            else
            {
                throw new UnauthorizedAccessException("Unauthorized access to student data.");
            }
        }
        public List<TblStudent> LoadStudentsFromDB()
        {
            StudentManagementSystemContext context = new StudentManagementSystemContext();


            return context.TblStudents.ToList();

        }

    }
}   
