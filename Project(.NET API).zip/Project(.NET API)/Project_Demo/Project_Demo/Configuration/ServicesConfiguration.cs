﻿using Project_Demo.Interfaces;
using Project_Demo.Services;

namespace Project_Demo.Configuration
{
    public static class ServicesConfiguration
    {
        public static IServiceCollection AddServices(this IServiceCollection services)
        {
            
            services.AddTransient<IStudentService, StudentService>();
            

            return services;
        }
    }
}
