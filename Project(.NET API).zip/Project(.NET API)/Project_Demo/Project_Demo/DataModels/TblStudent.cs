﻿using System;
using System.Collections.Generic;

namespace Project_Demo.DataModels
{
    public partial class TblStudent
    {
        public int StudentId { get; set; }
        public string? StudentName { get; set; }
    }
}
