﻿using Project_Demo.DataModels;
using Project_Demo.Models;

namespace Project_Demo.Interfaces
{
    public interface IStudentService
    {
        bool Authenticated(string username, string password);
        List<StudentModel> LoadStudents();
        public Task<IEnumerable<TblStudent>> LoadStudentsFromDB();
    }
}
