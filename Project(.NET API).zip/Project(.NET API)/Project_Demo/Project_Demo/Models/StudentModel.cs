﻿namespace Project_Demo.Models
{
    public class StudentModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
