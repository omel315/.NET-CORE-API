﻿using Project_Demo.DataModels;
using Project_Demo.Interfaces;
using Project_Demo.Models;
using System.Data.Entity;

namespace Project_Demo.Services
{
    public class StudentService : IStudentService
    {



        //public async Task<List<TblStudent>> LoadStudentsFromDB()
        //{
        //    return await GetStudentsFromDB();
        //}

        //private async Task<List<TblStudent>> GetStudentsFromDB()
        //{
        //    StudentManagementSystemContext context = new StudentManagementSystemContext();


        //    return await context.TblStudents.ToList();
        //}

        public async Task<IEnumerable<TblStudent>> LoadStudentsFromDB()
        {
            StudentManagementSystemContext context = new StudentManagementSystemContext();

            // Use ToAsyncEnumerable to create an IDbAsyncEnumerable wrapper
            var students = context.TblStudents.ToList();

            // Perform asynchronous iteration and return the results
            return students;
        }
        public List<StudentModel> LoadStudents()
        {
            List<StudentModel> students = new List<StudentModel>();
            StudentModel student = new StudentModel();
            student.Id = 1; student.Name = "Carol";

            students.Add(student);
            student = new StudentModel();
            student.Id = 2; student.Name = "Itemized";
            students.Add(student);
            student = new StudentModel();
            student.Id = 3; student.Name = "Michael";
            students.Add(student);
            student = new StudentModel();
            student.Id = 4; student.Name = "Stephen";
            students.Add(student);
            student = new StudentModel();
            student.Id = 5; student.Name = "Andrew";
            students.Add(student);
            return students;

        }
        
        public bool Authenticated(string username, string password)
        {
            bool authenticatedUser = false;
            if (!string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(password))
            {
                if (username == "admin" && password == "dev")
                {
                    return true;
                }

            }
            return authenticatedUser;

        }
    }
}
