

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'tbl_Student')
BEGIN
CREATE TABLE tbl_Student 
(
 Student_ID INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
 Student_Name VARCHAR(500) 
)ON [PRIMARY]
END;
---------------------------------------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM tbl_Student WHERE Student_Name ='Carol Christine')
BEGIN
INSERT INTO tbl_Student
           (Student_Name)
     VALUES
           ('Carol Christine')
END